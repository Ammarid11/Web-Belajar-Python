/* =====================================================================
   PYTHON ODYSSEY - cloud.js
   Login Supabase + hybrid storage:
   - localStorage tetap jadi penyimpanan utama (cepat, jalan offline)
   - bila sudah login, progress disinkronkan ke tabel `progress` di Supabase
   Isi dua konstanta di bawah (Supabase > Project Settings > API), lalu jalankan schema.sql.
   ===================================================================== */
(function () {
    "use strict";

    const SUPABASE_URL = "https://YOUR-PROJECT.supabase.co";
    const SUPABASE_ANON_KEY = "YOUR-ANON-KEY"; // kunci anon/publishable (aman di browser berkat RLS)

    const TABLE = "progress";
    const STORAGE_KEY = "pythonOdyssey.v2";
    const OWNER_KEY = "pythonOdyssey.owner";
    const GUEST_KEY = "pythonOdyssey.guest";
    const configured = /^https:\/\/[\w-]+\.supabase\.co/.test(SUPABASE_URL) && SUPABASE_ANON_KEY.indexOf("YOUR-") !== 0 && !!window.supabase;

    let sb = null, user = null, dirty = false, pushing = false, timer = null, status = "local";
    const $ = function (id) { return document.getElementById(id); };
    const app = function () { return window.OdysseyApp; };
    const EMPTY = function () { return { version: 2, savedAt: 0, done: {}, drafts: {}, settings: { lockOrder: false } }; };

    /* ---------- Status di header ---------- */
    const LABEL = {
        local: "💾 Lokal", guest: "👤 Masuk", sync: "⏳ Menyinkronkan…",
        synced: "☁ Tersinkron", error: "⚠ Gagal sinkron"
    };
    function setStatus(s) {
        status = s;
        const b = $("btn-account");
        if (b) b.textContent = LABEL[s] + (user && s !== "sync" ? " · " + user.email.split("@")[0] : "");
    }

    /* ---------- Merge: gabungkan progress lokal & cloud tanpa kehilangan soal selesai ---------- */
    function merge(a, b) {
        const newer = (a.savedAt || 0) >= (b.savedAt || 0) ? a : b;
        const older = newer === a ? b : a;
        const done = {};
        [a, b].forEach(function (s) {
            Object.keys(s.done || {}).forEach(function (id) {
                done[id] = Array.from(new Set((done[id] || []).concat(s.done[id])));
            });
        });
        return {
            version: 2, savedAt: Math.max(a.savedAt || 0, b.savedAt || 0), done: done,
            drafts: Object.assign({}, older.drafts, newer.drafts),
            settings: newer.settings, last: newer.last
        };
    }

    /* ---------- Sinkronisasi ---------- */
    async function pull() {
        const r = await sb.from(TABLE).select("data").eq("user_id", user.id).maybeSingle();
        if (r.error) throw r.error;
        return r.data ? r.data.data : null;
    }
    async function push(data) {
        const r = await sb.from(TABLE).upsert({ user_id: user.id, data: data, updated_at: new Date().toISOString() }, { onConflict: "user_id" });
        if (r.error) throw r.error;
    }

    async function syncOnLogin() {
        setStatus("sync");
        try {
            let local = app().serialize();
            const prev = localStorage.getItem(OWNER_KEY);
            if (prev && prev !== user.id) local = EMPTY(); // data lokal milik akun lain: jangan dicampur
            const cloud = await pull();
            const merged = cloud ? merge(local, cloud) : local;
            localStorage.setItem(OWNER_KEY, user.id);
            app().apply(merged);
            await push(merged);
            setStatus("synced");
        } catch (e) {
            console.error(e);
            setStatus("error");
            schedule(15000);
        }
    }

    function schedule(ms) { clearTimeout(timer); timer = setTimeout(flush, ms); }
    async function flush() {
        if (!user || pushing || !dirty) return;
        pushing = true; dirty = false; setStatus("sync");
        try { await push(app().serialize()); setStatus("synced"); }
        catch (e) { console.error(e); dirty = true; setStatus("error"); schedule(15000); }
        finally { pushing = false; if (dirty && status !== "error") schedule(2500); }
    }
    function markDirty(now) {
        if (!user) return;
        dirty = true;
        schedule(now ? 0 : 2500);
    }

    /* ---------- UI Login / Akun ---------- */
    const ERR = {
        "Invalid login credentials": "Email atau kata sandi salah.",
        "Email not confirmed": "Email belum dikonfirmasi. Buka kotak masuk emailmu dan klik tautan konfirmasi.",
        "User already registered": "Email ini sudah terdaftar. Silakan masuk.",
        "Password should be at least 6 characters": "Kata sandi minimal 6 karakter."
    };
    const errText = function (e) { return ERR[e && e.message] || ("Terjadi kesalahan: " + ((e && e.message) || "coba lagi")); };

    function closeAuth() { const r = $("auth-root"); if (r) r.replaceChildren(); }

    function showAuth(view, forced) {
        let root = $("auth-root");
        if (!root) { root = document.createElement("div"); root.id = "auth-root"; document.body.appendChild(root); }
        const T = {
            login: ["Masuk ke Python Odyssey", "Progress belajarmu tersimpan di cloud dan bisa dibuka dari perangkat mana pun.", "Masuk"],
            register: ["Buat akun", "Daftar gratis. Progress yang sudah ada di perangkat ini akan ikut tersimpan.", "Daftar"],
            reset: ["Atur ulang kata sandi", "Masukkan emailmu. Kami kirim tautan untuk membuat kata sandi baru.", "Kirim tautan"],
            recovery: ["Buat kata sandi baru", "Masukkan kata sandi baru untuk akunmu.", "Simpan kata sandi"],
            account: ["Akun", user ? user.email : "", ""]
        }[view];

        const card = document.createElement("div");
        card.className = "auth-card";
        card.setAttribute("role", "dialog");
        card.setAttribute("aria-modal", "true");
        card.setAttribute("aria-labelledby", "auth-title");
        const h = document.createElement("h2"); h.id = "auth-title"; h.className = "text-xl font-extrabold text-white mb-1"; h.textContent = T[0];
        const p = document.createElement("p"); p.className = "text-sm text-slate-400 mb-5"; p.textContent = T[1];
        card.append(h, p);

        const msg = document.createElement("p");
        msg.className = "text-sm mt-3 min-h-[1.25rem]"; msg.setAttribute("role", "status"); msg.setAttribute("aria-live", "polite");
        const say = function (t, bad) { msg.textContent = t; msg.className = "text-sm mt-3 min-h-[1.25rem] " + (bad ? "text-rose-400" : "text-emerald-400"); };
        const btn = function (text, cls, fn) {
            const b = document.createElement("button"); b.type = "button"; b.textContent = text; b.className = cls; b.addEventListener("click", fn); return b;
        };
        const link = function (text, fn) { return btn(text, "text-xs text-slate-400 hover:text-slate-200 underline", fn); };
        const PRIMARY = "w-full px-4 py-3 rounded-xl bg-gradient-to-r from-indigo-600 to-cyan-500 text-white font-bold text-sm disabled:opacity-60";
        const field = function (id, type, label, auto) {
            const w = document.createElement("div"); w.className = "mb-3";
            const l = document.createElement("label"); l.htmlFor = id; l.className = "block text-xs font-semibold text-slate-400 mb-1"; l.textContent = label;
            const i = document.createElement("input"); i.id = id; i.type = type; i.className = "auth-input"; i.autocomplete = auto; i.required = true;
            w.append(l, i); card.appendChild(w); return i;
        };
        const val = function (id) { return $(id).value.trim(); };

        if (view === "account") {
            const info = document.createElement("p");
            info.className = "text-sm text-slate-300 mb-4";
            info.textContent = "Status: " + LABEL[status].replace(/^\S+\s/, "") + ". Progress disimpan di perangkat ini dan di cloud.";
            card.appendChild(info);
            card.append(
                btn("Sinkronkan sekarang", PRIMARY + " mb-2", async function () { dirty = true; await flush(); say(status === "synced" ? "Tersinkron." : "Gagal sinkron, akan dicoba lagi.", status !== "synced"); }),
                btn("Keluar", "w-full px-4 py-3 rounded-xl bg-rose-950/40 border border-rose-900/40 text-rose-300 font-semibold text-sm", signOut)
            );
        } else {
            const email = view === "recovery" ? null : field("auth-email", "email", "Email", "email");
            const pass = view === "reset" ? null : field("auth-pass", "password", view === "recovery" ? "Kata sandi baru" : "Kata sandi", view === "login" ? "current-password" : "new-password");
            const go = btn(T[2], PRIMARY + " mt-2", async function () {
                if ((email && !email.checkValidity()) || (pass && !pass.value)) { say("Isi semua kolom dengan benar.", true); return; }
                go.disabled = true; say("");
                try {
                    if (view === "login") {
                        const r = await sb.auth.signInWithPassword({ email: val("auth-email"), password: pass.value });
                        if (r.error) throw r.error;
                    } else if (view === "register") {
                        const r = await sb.auth.signUp({ email: val("auth-email"), password: pass.value, options: { emailRedirectTo: location.origin + location.pathname } });
                        if (r.error) throw r.error;
                        if (!r.data.session) say("Akun dibuat. Cek emailmu dan klik tautan konfirmasi, lalu masuk.");
                    } else if (view === "reset") {
                        const r = await sb.auth.resetPasswordForEmail(val("auth-email"), { redirectTo: location.origin + location.pathname });
                        if (r.error) throw r.error;
                        say("Tautan dikirim. Cek kotak masuk emailmu.");
                    } else {
                        const r = await sb.auth.updateUser({ password: pass.value });
                        if (r.error) throw r.error;
                        say("Kata sandi diperbarui."); setTimeout(closeAuth, 1200);
                    }
                } catch (e) { say(errText(e), true); }
                go.disabled = false;
            });
            card.append(go);
            card.addEventListener("keydown", function (e) { if (e.key === "Enter" && e.target.tagName === "INPUT") go.click(); });
        }
        card.appendChild(msg);

        const nav = document.createElement("div"); nav.className = "flex flex-wrap items-center justify-between gap-2 mt-4";
        if (view === "login") nav.append(link("Belum punya akun? Daftar", function () { showAuth("register", forced); }), link("Lupa kata sandi?", function () { showAuth("reset", forced); }));
        else if (view === "register" || view === "reset") nav.append(link("Kembali ke Masuk", function () { showAuth("login", forced); }));
        if (forced && view !== "account" && view !== "recovery") {
            const guest = btn("Lanjut tanpa login (hanya di perangkat ini)", "w-full mt-3 text-xs text-slate-400 hover:text-slate-200 py-2", function () { localStorage.setItem(GUEST_KEY, "1"); setStatus("guest"); closeAuth(); });
            card.append(nav, guest);
        } else {
            nav.appendChild(link("Tutup", closeAuth));
            card.appendChild(nav);
        }
        root.replaceChildren(card);
        const first = card.querySelector("input, button"); if (first) first.focus();
    }

    async function signOut() {
        if (!window.confirm("Keluar? Progress di perangkat ini akan dihapus (tetap aman di cloud dan kembali saat kamu masuk lagi).")) return;
        dirty = true; await flush();
        if (status === "error") { toast("Progress belum tersinkron; coba lagi setelah online agar tidak hilang."); return; }
        await sb.auth.signOut();
        user = null;
        try { localStorage.removeItem(OWNER_KEY); localStorage.removeItem(STORAGE_KEY); } catch (e) { /* abaikan */ }
        app().apply(EMPTY());
        setStatus("guest");
        showAuth("login", true);
    }
    function toast(t) { window.alert(t); }

    /* ---------- Sesi ---------- */
    function startSession(session) {
        if (!session || (user && user.id === session.user.id)) return;
        user = session.user;
        localStorage.removeItem(GUEST_KEY);
        closeAuth();
        syncOnLogin();
    }

    async function init() {
        const badge = $("btn-account");
        if (!configured) {
            setStatus("local");
            badge.addEventListener("click", function () {
                window.alert("Cloud belum aktif. Isi SUPABASE_URL dan SUPABASE_ANON_KEY di cloud.js, lalu jalankan schema.sql di Supabase.");
            });
            return;
        }
        sb = window.supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY, { auth: { persistSession: true, autoRefreshToken: true, detectSessionInUrl: true } });
        window.OdysseyCloud = { markDirty: markDirty };
        badge.addEventListener("click", function () { if (user) showAuth("account"); else showAuth("login"); });
        window.addEventListener("online", function () { if (dirty) flush(); });
        document.addEventListener("visibilitychange", function () { if (document.visibilityState === "hidden" && dirty) flush(); });

        sb.auth.onAuthStateChange(function (ev, session) {
            setTimeout(function () {
                if (ev === "PASSWORD_RECOVERY") showAuth("recovery");
                else if (ev === "SIGNED_IN") startSession(session);
                else if (ev === "SIGNED_OUT") { user = null; setStatus("guest"); }
            }, 0);
        });
        const r = await sb.auth.getSession();
        if (r.data && r.data.session) startSession(r.data.session);
        else {
            setStatus("guest");
            if (!localStorage.getItem(GUEST_KEY)) showAuth("login", true);
        }
    }

    if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", init);
    else init();
})();
